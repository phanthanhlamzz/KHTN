# CoSoDuLieu
Đây là tài liệu để mình hướng dẫn trên kênh youtube Tủ Sách Vàng: 
https://www.youtube.com/watch?v=d3faUAXDIiA&list=PLYWC7VlGXIfWCAQTGOF2BF-W93hyO5wYw 
Liên hệ: 0888.888.441 (Zalo) 
https://www.facebook.com/datmatrung 
https://www.youtube.com/tusachvang
